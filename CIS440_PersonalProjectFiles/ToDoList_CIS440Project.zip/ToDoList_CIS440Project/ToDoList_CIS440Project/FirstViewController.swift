//
//  FirstViewController.swift
//  ToDoList_CIS440Project
//
//  Created by Michael Buckley on 11/24/14.
//  Copyright (c) 2014 BucksApps. All rights reserved.
//
// ************************************************
// ************************************************
// **                                            **
// **      _________  __________   ________      **
// **     /         \/          \ /        \     **
// **    |      ____/\___    ___/|    _____/     **
// **    |     /         |  |    |   |_____      **
// **    |    |          |  |    |         \     **
// **    |    |          |  |    \______   |     **
// **    |     \____  ___|  |___  ______|  |     **
// **    |          \/          \/         |     **
// **     \_________/\__________/\________/      **
// **                                            **
// **                                            **
// ************************************************
// ************************************************

import UIKit

// This is an array of strings which holds to do list items
// The array being outside of the first view controller class allows it to
// be used in both view controllers (screens)
var toDoItems:[String] = []

class FirstViewController: UIViewController, UITableViewDelegate {
    
    
    // This declaration allows me to reference the TableView which contains the toDoList items
    @IBOutlet var tasksTable:UITableView!
    
    
    override func viewDidLoad() {

        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    
    }
    
    // This function creates how many rows are in the table view
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        // The table view will have as many rows as there are items in the array
        return toDoItems.count
    
    }
    
   // This function inserts the to do item array in to the rows of the table view
    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) ->
        
        UITableViewCell! {
        
        var cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell")
        
        cell.textLabel.text = toDoItems[indexPath.row]
        
        return cell
            
    }
    
    // This function executes when the app is changed from the second view controller to the first
    override func viewWillAppear(animated: Bool) {
        
        // If there are items in the object the array will be updated
        if var storedToDoItems : AnyObject = NSUserDefaults.standardUserDefaults().objectForKey("toDoItems") {
            
            toDoItems = []
            
            // This for loop is to add the objects to the array
            for var i = 0; i < storedToDoItems.count; ++i {
                // This appends the array and converts the obeject to a string
                toDoItems.append(storedToDoItems[i] as NSString)
            
            }
            
        }
        // This updates the to do list
        tasksTable.reloadData()
        
    }
    
    // This function allows users to remove items from the to do list
    func tableView(tableView: UITableView!, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath!) {
        
        // Is the user trying to delete something?
        if (editingStyle == UITableViewCellEditingStyle.Delete) {
            
            // This finds where the user is trying to remove a to do item
            toDoItems.removeAtIndex(indexPath.row)
            
            // This updates our storage
            let fixedtoDoItems = toDoItems
            NSUserDefaults.standardUserDefaults().setObject(fixedtoDoItems, forKey: "toDoItems")
            NSUserDefaults.standardUserDefaults().synchronize()
            
            // This updates the table
            tasksTable.reloadData()
            
        }
        
    }

}

