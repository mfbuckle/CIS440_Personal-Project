//
//  SecondViewController.swift
//  ToDoList_CIS440Project
//
//  Created by Michael Buckley on 11/24/14.
//  Copyright (c) 2014 BucksApps. All rights reserved.
//
// ************************************************
// ************************************************
// **                                            **
// **      _________  __________   ________      **
// **     /         \/          \ /        \     **
// **    |      ____/\___    ___/|    _____/     **
// **    |     /         |  |    |   |_____      **
// **    |    |          |  |    |         \     **
// **    |    |          |  |    \______   |     **
// **    |     \____  ___|  |___  ______|  |     **
// **    |          \/          \/         |     **
// **     \_________/\__________/\________/      **
// **                                            **
// **                                            **
// ************************************************
// ************************************************

import UIKit

class SecondViewController: UIViewController, UITextFieldDelegate {
    
    // This is the text field and button
    @IBOutlet weak var toDoItem: UITextField!
    
    // This label displays how many to do items are on the to do list
    @IBOutlet weak var numberOfItems: UILabel!
    
    // This button will add an item to the to do list
    @IBAction func addItem(sender: AnyObject) {
        
        // When button is clicked the to do item is added to the end of the array
        toDoItems.append(toDoItem.text)
        
        // This stores the array for future use when you leave and return back to the app
        let fixedToDoItems = toDoItems
        // Sets the toDoItems array to the fixedToDoItems array
        NSUserDefaults.standardUserDefaults().setObject(fixedToDoItems, forKey: "toDoItems")
        // This saves the array
        NSUserDefaults.standardUserDefaults().synchronize()
        
        // This brings down the keyboard on clicking
        self.view.endEditing(true)
        
        // This clears the text field on click
        toDoItem.text = nil
        
        // This will update the label on click
        // This variable finds the number of items are in the array and casts the int as a string
        var numToDoItems = String(toDoItems.count)
        // Inserting text in to the label
        numberOfItems.text = "You have " + numToDoItems + " items on your to do list."
        
    }
    
    override func viewWillAppear(animated: Bool) {
        numberOfItems.reloadInputViews()
        // This will update the label after returning from first view controller
        // This variable finds the number of items are in the array and casts the int as a string
        var numToDoItems = String(toDoItems.count)
        // Inserting text in to the label
        numberOfItems.text = "You have " + numToDoItems + " items on your to do list."
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // This will load the text field upon opening the app
        // This variable finds the number of items are in the array and casts the int as a string
        var numToDoItems = String(toDoItems.count)
        // Inserting text in to the label
        numberOfItems.text = "You have " + numToDoItems + " items on your to do list."
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
    
    // This function will bring down the keyboard when the 'return' button is pressed
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    
    }
    
    // This function will bring down the keyboard when the screen is clicked away from the keyboard
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        
        self.view.endEditing(true)
        
    }


}

